package @PROJETO_NOME@.dominio;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "USUARIO")
@NamedQueries({
    @NamedQuery(name = "usuarioLogin", query = "from Usuario where email = :login and senha = SHA1(:senha)")
})
public class Usuario implements Serializable, org.voya.core.security.Usuario {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Long id;
    
    @Column(name = "NOME")
    private String nome;
    
    @Column(name = "EMAIL")
    private String email;
    
    @Column(name = "SENHA")
    private String senha;
    
    @Column(name = "DATA_HORA_LOG")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataHoraLog;

    public Usuario() {
    }

    public Usuario(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Date getDataHoraLog() {
        return dataHoraLog;
    }

    public void setDataHoraLog(Date dataHoraLog) {
        this.dataHoraLog = dataHoraLog;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuario)) {
            return false;
        }
        Usuario other = (Usuario) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "agenda.dominio.Usuario[ id=" + id + " ]";
    }

    @Override
    public String getLogin() {
        return getEmail();
    }

    @Override
    public void setLogin(String valor) {
        setEmail(valor);
    }

    @Override
    public String getPerfil() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void setPerfil(String string) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
