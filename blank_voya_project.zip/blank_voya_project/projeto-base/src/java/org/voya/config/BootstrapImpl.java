package org.voya.config;

import @PROJETO_NOME@.dominio.Usuario;

public class BootstrapImpl extends org.voya.core.Bootstrap
{
    @Override
    public void inicializar() 
    {
        /*ConvertUtils.register(new ConversorClasseDominio(), Veiculo.class);
        ConvertUtils.register(new ConversorClasseDominio(), Motor.class);
        ConvertUtils.register(new ConversorClasseDominio(), Fabricante.class);
        ConvertUtils.register(new ConversorClasseDominio(), Modelo.class);*/
    }

    //Esse método deve ser usado quando o usuário quiser utilizar o controlador
    //padrão de login e logout do Voya.
    //A partir da classe informada o Voya acessará o banco corretamente a procura do usuário
    @Override
    public Class getClassUsuario() {
        return Usuario.class;
    }

    //Esse método deve ser usado quando o usuário quiser utilizar o controlador
    //padrão de login e logout do Voya. Se o login for realizado com sucesso
    //o mesmo seguirá para este caminho
    @Override
    public String getFirstPage() {
        return "Modelo/index";
    }    
}
