package @PROJETO_NOME@.controle;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.voya.core.security.SecuredController;

public class ModeloController implements SecuredController{
    
    private HttpServletRequest request;
    private HttpServletResponse response;
    
    public ModeloController(HttpServletRequest req, HttpServletResponse res)
    {
        this.request = req;
        this.response = res; 
    }
    
    //O método da classe pode ter como parametro o servletrequest
    //pode não ter parametro nenhum
    //ou pode ter como parametro um bean que será populado com as infomações
    //que virão de um formulário
    public String index(HttpServletRequest req) throws Exception
    {
        return "/WEB-INF/templates/main.vm";
    }
    
    @Override
    public boolean acessoPermitido(org.voya.core.security.Usuario usr, String metodo) {
        return true;
    }
    
}
