package @PROJETO_NOME@.servico;

import @PROJETO_NOME@.dominio.Usuario;
import java.util.List;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import org.voya.core.EMUtil;

public class ModeloServico {
    private static ModeloServico fachada;
    
    private ModeloServico()
    {
        
    }
    
    /**
     * Retorna a instância (singleton) da fachada.
     */
    public static ModeloServico getInstance()
    {
        if (fachada == null)
        {
            fachada = new ModeloServico();
        }
        
        return fachada;
    }
    
    public Usuario buscarPorEmail(String email) throws Exception
    {
        EntityManager em = EMUtil.getEntityManager();
        EntityTransaction tx = null;
        
        Usuario retorno = null;
        
        try
        {
            tx = em.getTransaction();
            tx.begin();
            Query q = em.createQuery("from Usuario where email = :email");
            q.setParameter("email", email);
            retorno = (Usuario) q.getSingleResult();
            
            tx.commit();
        }
        catch (EntityExistsException e)
        {
            if ( tx != null && tx.isActive() )
                tx.rollback();
            throw e;
        }
        catch (PersistenceException e)
        {
            if ( tx != null && tx.isActive() )
                tx.rollback();
            throw e;
        }
        catch (Exception e)
        {
            if ( tx != null && tx.isActive() )
                tx.rollback();
            throw e;
        }
        finally
        {
            em.close();
        }
        
        return retorno;
    }    
    
}
